<?php
/**
 * Plugin Name: My PDF Download with TCPDF
 * Description: Provides a button to download the page as a PDF using TCPDF, with customizable headers and footers.
 * Version: 1.0
 * Author: Your Name
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Admin settings to customize the PDF header and footer
add_action('admin_menu', 'my_pdf_plugin_settings_page');
function my_pdf_plugin_settings_page() {
    add_options_page('PDF Settings', 'PDF Settings', 'manage_options', 'my-pdf-settings', 'my_pdf_settings_page');
}

add_action('admin_init', 'my_pdf_register_settings');
function my_pdf_register_settings() {
    register_setting('my-pdf-settings-group', 'my_pdf_logo');
    register_setting('my-pdf-settings-group', 'my_pdf_helpline');
    register_setting('my-pdf-settings-group', 'my_pdf_footer_text');
    register_setting('my-pdf-settings-group', 'my_pdf_website');
}

function my_pdf_settings_page() {
    ?>
    <div class="wrap">
        <h2>Your PDF Header and Footer Settings</h2>
        <form method="post" action="options.php">
            <?php settings_fields('my-pdf-settings-group'); ?>
            <?php do_settings_sections('my-pdf-settings-group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">PDF Logo URL</th>
                    <td><input type="text" name="my_pdf_logo" value="<?php echo esc_attr(get_option('my_pdf_logo')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Helpline Number</th>
                    <td><input type="text" name="my_pdf_helpline" value="<?php echo esc_attr(get_option('my_pdf_helpline')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Footer Text</th>
                    <td><input type="text" name="my_pdf_footer_text" value="<?php echo esc_attr(get_option('my_pdf_footer_text')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Website URL</th>
                    <td><input type="text" name="my_pdf_website" value="<?php echo esc_attr(get_option('my_pdf_website')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Register shortcode that outputs the PDF download link
add_shortcode('my_pdf_download', 'my_pdf_download_shortcode');
function my_pdf_download_shortcode() {
    $url = add_query_arg('download_pdf', 'true', get_permalink());
    return '<a href="' . esc_url($url) . '" class="download-pdf-button">Download PDF</a>';
}

// Hook to check for the PDF download trigger
add_action('template_redirect', 'my_check_for_pdf_download');
function my_check_for_pdf_download() {
    if (isset($_GET['download_pdf']) && $_GET['download_pdf'] == 'true') {
        my_pdf_generate_with_tcpdf();
    }
}

function my_pdf_generate_with_tcpdf() {
    require_once(plugin_dir_path(__FILE__) . 'TCPDF/tcpdf.php'); // Make sure this path is correct
    $pdf = new TCPDF();
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Your Name');
    $pdf->SetTitle('Download PDF');
    $pdf->SetSubject('Generated PDF');
    $pdf->setHeaderData(get_option('my_pdf_logo'), 30, get_option('my_pdf_website'), "Helpline: " . get_option('my_pdf_helpline'));
    $pdf->setFooterData(array(0,64,0), array(0,64,128), get_option('my_pdf_logo'), get_option('my_pdf_footer_text'));
    $pdf->AddPage();

    ob_start();
    the_content();
    $content = ob_get_clean();
    
    // Adding CSS to hide the download button in the PDF output
    $html = '<style>.download-pdf-button { display: none; }</style>' . $content;
    $pdf->writeHTML($html, true, false, true, false, '');

    $pdf->Output('filename.pdf', 'D'); // This sends the PDF as a download
    exit;
}

